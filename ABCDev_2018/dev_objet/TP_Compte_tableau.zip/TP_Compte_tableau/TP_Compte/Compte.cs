﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_Compte
{
    public class Compte : IDisposable
    {

        private int numero;
        private string nomProprietaire;

        public string NomProprietaire
        {
            get { return nomProprietaire; }
            set { nomProprietaire = value; }
        } 
        private float solde;
        private float decouvertAutorise;
        //private bool disposed = false;
        //private IntPtr handle;

        //propriété
        public int getNumero() { return this.numero; }
        public float getDecouvertAutorise() { return this.decouvertAutorise; }
        public float Solde
        {
            get { return solde; }
            set { solde = value; }
        }
        //Constructeur
        public Compte()
        {
            Random alea = new Random();
            this.numero = alea.Next(10000, 100000);
            this.nomProprietaire = "Compte technique";
            this.solde = 0.00F;
            this.decouvertAutorise = 0.00F;
        }

         ~Compte()
        {
            // Do not re-create Dispose clean-up code here.
            // Calling Dispose(false) is optimal in terms of
            // readability and maintainability.
            Dispose();
        }
        public Compte(int _num, string _Nproprio, float _sld, float _decouvAuto)
        {
            this.numero = _num;
            this.nomProprietaire = _Nproprio;
            this.solde = _sld;
            this.decouvertAutorise = _decouvAuto;
        }
        //Méthodes

        public override string ToString()
        {
            string chaine = "Ce compte a pour numéro : " + numero + "\nProprietaire : " + nomProprietaire + "\nLe solde est de : " + solde + "\nSon DA est de : " + decouvertAutorise+"\n-------------------------------";
            return chaine;
        }
        //public void Afficher()
        //{
        //    Console.WriteLine(this/*.ToString()*/);
        //}
        public void Crediter(float _montant)
        {
            this.Solde += _montant;
        }

        public bool Debiter(float _montant)
        {
            bool autor = false;
            float nouvSolde = this.Solde - _montant;
            if (nouvSolde >= this.decouvertAutorise)
            {
                autor = true;
                this.Solde -= _montant;
                return autor;
            }
            else
            {
                return autor;
            }
        }

        public bool Transferer(float _montant, Compte _autreCompte)
        {
           bool test =this.Debiter(_montant);
            if (test)
            {                
                _autreCompte.Crediter(_montant);
                return true;
            }
            return false;
        }

        public bool Superieur(Compte _autreCompte)
        {
            if (this.Solde > _autreCompte.Solde)
            {
                return true;
            }
            return false;
        }
       
        public void Dispose()
        {
           // GC.SuppressFinalize(this);
            Console.WriteLine("Le compte " + this.getNumero() + " a bien été suprimé.");                    
        }

    }
}
