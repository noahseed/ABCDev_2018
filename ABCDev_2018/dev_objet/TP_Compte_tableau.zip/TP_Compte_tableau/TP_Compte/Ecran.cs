﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_Compte
{
    public class Ecran
    {

        public static void AfficherCompte(Compte _monCompte)
        {
            Console.WriteLine(_monCompte.ToString());
        }
        public static void AffiBanque(Compte[] _banque,int nbCompte)
        {
            for (int i = 0; i < nbCompte; i++)
            {
                AfficherCompte(_banque[i]);
            }

            //foreach (Compte item in _banque)
            //{

            //  //  Console.WriteLine(item.ToString());
            //    AfficherCompte(item);
            //}
        }
        public static void AffiBanque(List<Compte> _banque)
        {
            foreach (Compte item in _banque)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
