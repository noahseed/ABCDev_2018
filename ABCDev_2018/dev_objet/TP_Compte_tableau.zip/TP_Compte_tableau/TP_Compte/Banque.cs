﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_Compte
{
    public class Banque
    {
        private int nbComptes;

        public int NbComptes
        {
            get { return nbComptes; }
            set { nbComptes = value; }
        }
        private Compte[] LesComptes;

        public Compte[] LesComptes1
        {
            get { return LesComptes; }
            set { LesComptes = value; }
        }


        public Banque()
        {
            LesComptes = new Compte[20];
            this.nbComptes = 0;
        }

        private void AjouteCompte(Compte unCompte)
        {
            LesComptes[nbComptes++] = unCompte;
        }

        public void Init()
        {
            Compte c1 = new Compte(12345, "toto", 1000, -500);
            Compte c2 = new Compte(45657, "titi", 2000, -1000);
            Compte c3 = new Compte(32345, "dupond", 1500, -1500);
            Compte c4 = new Compte(11633, "durand", 1200, -500);
            Compte c5 = new Compte(2568, "dubois", -200, -500);
            Compte c6 = new Compte(8978, "duval", 750, -2000);
            this.AjouteCompte(c1);
            this.AjouteCompte(c2);
            this.AjouteCompte(c3);
            this.AjouteCompte(c4);
            this.AjouteCompte(c5);
            this.AjouteCompte(c6);
        }

        public void AjouteCompte(int n, string nom, float solde, float dec)
        {
            Compte unCompte = new Compte(n, nom, solde, dec);

            AjouteCompte(unCompte);
        }
        public Compte Comptesup()
        {
            int indicemax = 0;
                for (int i = 1; i < NbComptes; i++)
			{
                if (LesComptes[i].Superieur(LesComptes[indicemax])==true)
                {
                    indicemax = i;
                }     			 
			}
                return LesComptes[indicemax];
        }
        public Compte RendCompte(int _num)
        {
            bool test = false;
            for (int i = 0; i < nbComptes; i++)
            {
                if (LesComptes[i].getNumero()==_num)
                {
                    test = true;
                    return LesComptes[i];
                }     
            }
            return new Compte();
        }
        public bool Virement(int _num, int _num2, float _montant)
        {
            bool test;
            Compte Comptedebit = this.RendCompte(_num);
            Compte Comptecredit = this.RendCompte(_num2);
            if (Comptedebit.NomProprietaire!="Compte technique" && Comptecredit.NomProprietaire!="Compte technique")
            {
                if (Comptedebit.Transferer(_montant,Comptecredit))
                {
                   // Console.WriteLine("Virement effectué");
                    test = true;
                }
                else
	            {
                    Console.WriteLine("dépassement de découvert autorisé. Veuillez contacter votre conseiller");
                    test = false;
	            }
            }
            else
            {
                Console.WriteLine("Compte à débiter ou bénéficiaire inexistant!!!");
                test = false;
            }
            return test;
        
        }
    }
}
