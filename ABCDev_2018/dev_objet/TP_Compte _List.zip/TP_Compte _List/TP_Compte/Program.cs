﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_Compte
{
    class Program
    {
        static void Main(string[] args)
        {

            Compte compte1 = new Compte(12345, "Tournesol", 2000.50F, -1000);
            Compte compte2 = new Compte(56789, "Tintin", 5000, -500);

            Console.WriteLine("Montant avant débit");

            //   compte1.Afficher();
            //  compte2.Afficher();
            //Ecran.AfficherCompte(compte1);
            //Ecran.AfficherCompte(compte2);

            //   bool test = compte1.Debiter(3000.5F);
            //if (test)
            //{
            //    Console.WriteLine("Montant après débit de 3000 euros");
            //    Ecran.AfficherCompte(compte1);
            //}
            //else
            //{
            //    Console.WriteLine("Opération refusée, fonds insuffisants");
            //}
          //  Console.WriteLine("Tintin effectue un virement de : 2000 Euros en faveur de Tryphon Tournesol");
          //  bool test2 = compte2.Transferer(2000, compte1);
          //  if (test2)
          //  {
          //      Console.WriteLine("Opération effectuée !!! ");
          //      Ecran.AfficherCompte(compte2);
          //      Ecran.AfficherCompte(compte1);
          //  }
          //  else
          //  {
          //      Console.WriteLine("Opération refusée compte de Tintin pas assez approvisionné !!! ");
          //  }
          ////  compte2.Crediter(4000);
          //  bool test3 = compte1.Superieur(compte2);
          //  if (test3)
          //  {
          //      Console.WriteLine("Le compte numéro" + compte1.getNumero() + " de " + compte1.NomProprietaire + " est bien supérieur au compte de " + compte2.NomProprietaire);
          //  }
          //  else
          //  {
          //      Console.WriteLine("Le compte numéro" + compte1.getNumero() + " de " + compte1.NomProprietaire + " est bien inférieur ou égal au compte de " + compte2.NomProprietaire);
          //  }

          //  // compte2.Dispose();
          //  //compte1.Afficher();

          //  Console.Clear();

          //  Banque b = new Banque();
          //  b.Init();
            
            Banque BNP = new Banque();
            BNP.AjouteCompte(compte1);
            BNP.AjouteCompte(compte2);

            BNP.AjouteCompte(1245, "Haddock", 11500, -2000);

            //Ecran.AffiBanque(BNP.MesComptes);
            Console.WriteLine("Le nombre de clients compte chèque de notre banque est " + BNP.NbComptes);
            BNP.AjouteCompte(78910, "lampion", 505.5F, -1000);
            Ecran.AffiBanque(BNP.MesComptes);
            Ecran.AfficherCompte(BNP.CompteSup());

            string reponse = "";

            bool testVir = BNP.Virement(789101, 1245, 1000, out reponse);

            if (testVir)
            {
                Ecran.AfficherCompte(BNP.RendCompte(78910));
                Ecran.AfficherCompte(BNP.RendCompte(1245));
            }
            else
            {
                Console.WriteLine(reponse);
            }

            Console.ReadKey();
        }
    }
}
