﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_Compte
{
    public class Banque
    {
        ArrayList mesComptes;

        public ArrayList MesComptes
        {
            get { return mesComptes; }
            set { mesComptes = value; }
        }

        private int nbComptes;

        public int NbComptes
        {
            get { return nbComptes; }
            set { nbComptes = value; }
        }
      


        public Banque()
        {
            mesComptes = new ArrayList();
            this.Init();
            this.nbComptes = mesComptes.Count;
        }
        public void AjouteCompte(int _numero, string _nom, float _solde, float _da)
        {
            //this.MesComptes.Add(new Compte(_numero, _nom, _solde, _da));
            //this.nbComptes = mesComptes.Count;
            this.AjouteCompte(new Compte(_numero, _nom, _solde, _da));
        }

        public void AjouteCompte(Compte unCompte)
        {
            mesComptes.Add(unCompte);
            this.nbComptes = mesComptes.Count;
        }

        public void Init()
        {
            Compte c1 = new Compte(12345, "toto", 1000, -500);
            mesComptes.Add(c1);
            Compte c2 = new Compte(45657, "titi", 2000, -1000);
            mesComptes.Add(c2);
            Compte c3 = new Compte(32345, "dupond", 1500, -1500);
            mesComptes.Add(c3);
            Compte c4 = new Compte(11633, "durand", 1200, -500);
            mesComptes.Add(c4);
            Compte c5 = new Compte(2568, "dubois", -200, -500);
            mesComptes.Add(c5);
            mesComptes.Add(new Compte(8978, "duval", 750, -2000));
        }

        public Compte CompteSup()
        {
            mesComptes.Sort();
            Compte Max = (Compte) mesComptes[0];
            return Max;
        }

        public Compte RendCompte(int _numero)
        {
            for (int i = 0; i < mesComptes.Count; i++)
            {
                if (((Compte)mesComptes[i]).getNumero() == _numero)
                {
                    return ((Compte)mesComptes[i]);
                }
            }
            return new Compte();
        }

        public bool Virement(int _compteADebiter, int _compteACrediter, float _montant, out string _autorisation)
        {
            bool test;

            if (RendCompte(_compteADebiter).NomProprietaire != "Compte technique"
                && RendCompte(_compteACrediter).NomProprietaire != "Compte technique")
            {
                test = RendCompte(_compteADebiter).Transferer(_montant, RendCompte(_compteACrediter));

                if (test == false)
                {
                    _autorisation = "Provisions insuffisantes ou montant négatif, opération refusée.";
                }
                else
                {
                    _autorisation = "Virement effectué";
                }

            }
            else
            {
                _autorisation = "Compte inexistant";
                test = false;
            }
            return test;
        }

        
    }
}
